import os
import nextcord
import asyncio
from nextcord.ext import commands
from utils.config import BOT_TOKEN
from nextcord import *
from colorama import init, Fore, Back, Style
init()

bot = commands.Bot(intents=Intents.all(), help_command=None)

@bot.event
async def on_ready():
    await asyncio.sleep(1)
    os.system("clear")
    print(Fore.RED + "All Cogs is loaded")

    await asyncio.sleep(1)
    os.system("clear")
    print(Fore.LIGHTGREEN_EX + "\n-----------[Kaity Ez]-----------")
    print(Fore.GREEN + "\n🚀", Fore.BLUE + bot.user.name, Fore.GREEN + "is online!")
    print(Fore.GREEN + "🔧 Bot ID:", Fore.YELLOW + f"{bot.user.id}")
    print(Fore.GREEN + "🌐 Connected to", Fore.YELLOW + f"{len(bot.guilds)}", Fore.GREEN + "servers")
    print(Fore.GREEN + "🤖 Running on", Fore.BLUE + "Nextcord", Fore.YELLOW + f"v{nextcord.__version__}", Fore.GREEN + "")

for filename in os.listdir('./cogs'):
    if filename.endswith('_cog.py'):
        module = f'cogs.{filename[:-3]}'
        bot.load_extension(module)
        print(Fore.GREEN + "[loaded]", Fore.LIGHTBLUE_EX + module)

        
 
if __name__ == '__main__':
    bot.run(BOT_TOKEN)

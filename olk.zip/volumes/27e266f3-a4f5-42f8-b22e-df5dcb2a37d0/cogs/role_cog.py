import nextcord
from nextcord.ext import commands
from nextcord import slash_command, SlashOption

class RoleManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(name="role", description="[🗣️] จัดการบทบาทในเซิร์ฟเวอร์")
    async def role(self, interaction: nextcord.Interaction):
        pass

    @role.subcommand(name="create", description="[🗣️] สร้างบทบาทใหม่")
    async def create_role(
        self,
        interaction: nextcord.Interaction,
        name: str = SlashOption(name="ชื่อ", description="ชื่อของบทบาท"),
        color: str = SlashOption(name="สี", description="สีของบทบาท (รหัสสีแบบ hex)", required=False),
        hoist: bool = SlashOption(name="แยกแสดง", description="แสดงบทบาทแยกต่างหากหรือไม่", required=False, default=False),
        mentionable: bool = SlashOption(name="กล่าวถึงได้", description="สามารถกล่าวถึงบทบาทได้หรือไม่", required=False, default=False)
    ):
        if not interaction.user.guild_permissions.manage_roles:
            await interaction.response.send_message("คุณไม่มีสิทธิ์ในการจัดการบทบาท", ephemeral=True)
            return

        try:
            role_color = nextcord.Color(int(color.strip('#'), 16)) if color else nextcord.Color.default()
            new_role = await interaction.guild.create_role(name=name, color=role_color, hoist=hoist, mentionable=mentionable)
            await interaction.response.send_message(f"สร้างบทบาท '{new_role.name}' สำเร็จแล้ว!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"เกิดข้อผิดพลาด: {str(e)}", ephemeral=True)

    @role.subcommand(name="modify", description="[🗣️] แก้ไขบทบาทที่มีอยู่")
    async def modify_role(
        self,
        interaction: nextcord.Interaction,
        role: nextcord.Role = SlashOption(name="บทบาท", description="บทบาทที่ต้องการแก้ไข"),
        name: str = SlashOption(name="ชื่อใหม่", description="ชื่อใหม่สำหรับบทบาท", required=False),
        color: str = SlashOption(name="สีใหม่", description="สีใหม่สำหรับบทบาท (รหัสสีแบบ hex)", required=False),
        hoist: bool = SlashOption(name="แยกแสดง", description="แสดงบทบาทแยกต่างหากหรือไม่", required=False),
        mentionable: bool = SlashOption(name="กล่าวถึงได้", description="สามารถกล่าวถึงบทบาทได้หรือไม่", required=False)
    ):
        if not interaction.user.guild_permissions.manage_roles:
            await interaction.response.send_message("คุณไม่มีสิทธิ์ในการจัดการบทบาท", ephemeral=True)
            return

        try:
            if name:
                await role.edit(name=name)
            if color:
                role_color = nextcord.Color(int(color.strip('#'), 16))
                await role.edit(color=role_color)
            if hoist is not None:
                await role.edit(hoist=hoist)
            if mentionable is not None:
                await role.edit(mentionable=mentionable)

            await interaction.response.send_message(f"แก้ไขบทบาท '{role.name}' สำเร็จแล้ว!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"เกิดข้อผิดพลาด: {str(e)}", ephemeral=True)

    @role.subcommand(name="delete", description="[🗣️] ลบบทบาทที่มีอยู่")
    async def delete_role(
        self,
        interaction: nextcord.Interaction,
        role: nextcord.Role = SlashOption(name="บทบาท", description="บทบาทที่ต้องการลบ")
    ):
        if not interaction.user.guild_permissions.manage_roles:
            await interaction.response.send_message("คุณไม่มีสิทธิ์ในการจัดการบทบาท", ephemeral=True)
            return

        try:
            role_name = role.name
            await role.delete()
            await interaction.response.send_message(f"ลบบทบาท '{role_name}' สำเร็จแล้ว!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"เกิดข้อผิดพลาด: {str(e)}", ephemeral=True)

def setup(bot):
    bot.add_cog(RoleManagement(bot))

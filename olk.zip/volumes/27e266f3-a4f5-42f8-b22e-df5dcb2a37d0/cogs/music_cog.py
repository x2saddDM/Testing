import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
from collections import defaultdict
import mafic
from mafic import SearchType
import asyncio
import random
from utils.music_utils import create_embed, format_duration, voice_channel_check

class GuildMusicState:
    def __init__(self):
        self.queue = []
        self.current_track = None
        self.volume = 100
        self.disconnect_task = None
        self.autoplay = False

class MusicCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.pool = mafic.NodePool(self.bot)
        self.bot.guild_music_states = defaultdict(GuildMusicState)
        self.bot.loop.create_task(self.add_nodes())

    async def add_nodes(self):
        await self.bot.pool.create_node(
            host="163.5.120.74",
            port=25572,
            label="MAIN",
            password="youshallnotpass",
        )

    @nextcord.slash_command(dm_permission=False, description="[🌺] เล่นเพลงโดยการใส่ชื่อเพลงหรือลิ้งค์")
    async def play(self, inter: nextcord.Interaction, query: str = SlashOption(description="ลิ้งค์เพลง หรือ ชื่อเพลง")):
        await inter.response.defer()

        if not inter.user.voice:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "คุณต้องอยู่ในห้องเสียงก่อน", color=nextcord.Color.red())
            return await inter.followup.send(embed=embed)

        guild_state = self.bot.guild_music_states[inter.guild.id]
        if not inter.guild.voice_client:
            player = await inter.user.voice.channel.connect(cls=mafic.Player)
        else:
            player = inter.guild.voice_client
            if player.channel != inter.user.voice.channel:
                embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "คุณต้องอยู่ในห้องเสียงเดียวกับบอท", color=nextcord.Color.red())
                return await inter.followup.send(embed=embed)

        try:
            tracks = await player.fetch_tracks(query, search_type=SearchType.YOUTUBE_MUSIC)

        except Exception as e:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", f"เกิดข้อผิดพลาดในการค้นหาเพลง: {str(e)}", color=nextcord.Color.red())
            return await inter.followup.send(embed=embed)

        if not tracks:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ไม่พบผลลัพธ์", "ไม่พบเพลงที่คุณต้องการ", color=nextcord.Color.red())
            return await inter.followup.send(embed=embed)

        if isinstance(tracks, mafic.Playlist):
            playlist = tracks
            for track in playlist.tracks:
                guild_state.queue.append(track)
            if not guild_state.current_track:
                guild_state.current_track = playlist.tracks[0]
                await player.play(guild_state.current_track)
                

            embed = create_embed("", f"> **<a:experience:1276521604431482900> [{playlist.name}]({playlist.tracks[0].uri if playlist.tracks else ''})**")
            embed.set_author(name="🎵 | เพิ่มเพลงแล้ว", icon_url=self.bot.user.avatar.url)
            embed.set_thumbnail(url=playlist.tracks[0].artwork_url if playlist.tracks else None)
            embed.add_field(name="<:enchanted_book:1287070850633171026> ข้อมูลของ Playlist", value=f"┗ **{inter.user.mention}** ``{len(playlist.tracks)} เพลงจาก playlist``")
            embed.set_footer(text=f"🌺 {self.bot.user.name} | By KaiTy_Ez")
        else:
            track = tracks[0]
            if not guild_state.current_track:
                guild_state.current_track = track
                await player.play(track)
                status = "🎵 | กำลังเล่น"
            else:
                guild_state.queue.append(track)
                status = "🎵 | เพิ่มเพลงแล้ว"

            embed = create_embed("", f"> **<a:experience:1276521604431482900> [{track.title}]({track.uri})**")
            embed.set_author(name=status, icon_url=self.bot.user.avatar.url)
            embed.set_thumbnail(url=track.artwork_url)
            embed.add_field(name="<:enchanted_book:1287070850633171026> ข้อมูลของเพลง", value=f"┗ **{track.author}** ``{format_duration(track.length)}``")
            embed.set_footer(text=f"🌺 {self.bot.user.name} | By KaiTy_Ez")

        await inter.followup.send(embed=embed)
        await player.set_volume(guild_state.volume)

        if guild_state.disconnect_task:
            guild_state.disconnect_task.cancel()
            guild_state.disconnect_task = None


    @nextcord.slash_command(dm_permission=False, description="[🌺] เปิด/ปิด autoplay")
    async def autoplay(self, inter: nextcord.Interaction):
        guild_state = self.bot.guild_music_states[inter.guild.id]
        guild_state.autoplay = not guild_state.autoplay

        status = "เปิดใช้งาน" if guild_state.autoplay else "ปิดใช้งาน"
        embed = create_embed("🔄 โหมด Autoplay", f"Autoplay ได้ถูก {status} แล้ว")
        await inter.response.send_message(embed=embed)

    @commands.Cog.listener()
    async def on_track_end(self, event):
        guild_id = event.player.guild.id
        await self.play_next(guild_id)

    async def play_next(self, guild_id):
        guild_state = self.bot.guild_music_states[guild_id]
        player = self.bot.get_guild(guild_id).voice_client

        if guild_state.queue:
            next_track = guild_state.queue.pop(0)
            guild_state.current_track = next_track
            await player.play(next_track)
        else:
            guild_state.current_track = None
            if guild_state.autoplay:
                tracks = await player.fetch_tracks("lofi")
                if tracks:
                    next_track = random.choice(tracks)
                    guild_state.current_track = next_track
                    await player.play(next_track)
            else:
                guild_state.disconnect_task = asyncio.create_task(self.disconnect_after_timeout(guild_id))

    async def disconnect_after_timeout(self, guild_id):
        await asyncio.sleep(30)
        guild = self.bot.get_guild(guild_id)
        if guild and guild.voice_client:
            await guild.voice_client.disconnect()
        self.bot.guild_music_states[guild_id].disconnect_task = None

    @nextcord.slash_command(dm_permission=False, description="[🌺] หยุดเพลงที่กำลังเล่น")
    async def pause(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่สามารถเข้าห้องเสียงได้", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)

        player = inter.guild.voice_client
        if player.paused:
            embed = create_embed("⏸️ หยุดชั่วคราวแล้ว", "เพลงหยุดอยู่แล้ว", color=0xf39c12)
            return await inter.response.send_message(embed=embed)

        await player.pause()
        embed = create_embed("⏸️ หยุดชั่วคราว", "เพลงได้หยุดชั่วคราวแล้ว")
        await inter.response.send_message(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] ตรวจสอบสถานะของ Node")
    async def node(self, inter: nextcord.Interaction):
        await inter.response.defer()

        try:
            stats = self.bot.pool.nodes[0].stats
        except Exception as e:
            embed = create_embed("❌ ข้อผิดพลาด", f"เกิดข้อผิดพลาดในการดึงข้อมูล: {str(e)}", color=0xe74c3c)
            return await inter.followup.send(embed=embed)

        uptime = str(stats.uptime)
        memory_used = stats.memory.used / 1024 / 1024
        memory_free = stats.memory.free / 1024 / 1024
        memory_allocated = stats.memory.allocated / 1024 / 1024
        memory_reservable = stats.memory.reservable / 1024 / 1024
        cpu_load = stats.cpu.system_load
        lavalink_load = stats.cpu.lavalink_load
        player_count = stats.player_count
        playing_player_count = stats.playing_player_count
        
        embed = create_embed("🔍 สถานะของ Lavalink Node", f"""
```- Uptime: {uptime}
- Memory Used: {memory_used:.2f}/{memory_allocated:.2f} MiB
- CPU Load: {cpu_load:.2f}%
- Players Connected: {player_count}
- Playing Players: {playing_player_count}```
""")
        embed.set_author(name="Node Status", icon_url=self.bot.user.avatar.url)
        embed.set_footer(text=f"🌺 {self.bot.user.name} | By KaiTy_Ez")

        await inter.followup.send(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] ปรับระดับเสียงของบอท")
    async def volume(self, inter: nextcord.Interaction, volume: int = SlashOption(description="ระดับเสียง (1-100)")):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)

        if volume < 0 or volume > 100:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ระดับเสียงไม่ถูกต้อง", "ระดับเสียงต้องอยู่ระหว่าง 0 ถึง 100", color=nextcord.Color.blue)
            return await inter.response.send_message(embed=embed)

        guild_state = self.bot.guild_music_states[inter.guild.id]
        guild_state.volume = volume
        player = inter.guild.voice_client
        await player.set_volume(volume)
        embed = create_embed("🔊 เปลี่ยนระดับเสียง", f"ตั้งระดับเสียงเป็น {volume}%")
        await inter.response.send_message(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] ตัดการเชื่อมต่อของบอทและล้างคิว")
    async def disconnect(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)

        guild_state = self.bot.guild_music_states[inter.guild.id]
        guild_state.queue.clear()
        guild_state.current_track = None
        await inter.guild.voice_client.disconnect()
        embed = create_embed("👋 ตัดการเชื่อมต่อ", "ตัดการเชื่อมต่อจากห้องเสียงและล้างคิวแล้ว")
        await inter.response.send_message(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] ดูคิวและเพลงที่กำลังเล่นอยู่")
    async def queue(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
                return
        await inter.response.defer()
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)
    
        guild_state = self.bot.guild_music_states[inter.guild.id]
        if not guild_state.current_track and not guild_state.queue:
            embed = create_embed("📋 คิวว่างเปล่า", "ไม่มีเพลงในคิว", color=0xf39c12)
            return await inter.response.send_message(embed=embed)

        embed = create_embed("📋 คิวปัจจุบัน", "")
        if guild_state.current_track:
            embed.add_field(name="🎵 กำลังเล่น", value=f"[{guild_state.current_track.title}]({guild_state.current_track.uri}) | `{format_duration(guild_state.current_track.length)}`", inline=False)

        if guild_state.queue:
            queue_list = "\n".join([f"`{i+1}.` [{track.title}]({track.uri}) | `{format_duration(track.length)}`" for i, track in enumerate(guild_state.queue[:10])])
            embed.add_field(name="<a:soon:1286713974574022757> เพลงถัดไป", value=queue_list, inline=False)
        if len(guild_state.queue) > 10:
            embed.set_footer(text=f"แสดง 10 เพลงแรกจากทั้งหมด {len(guild_state.queue)} เพลง")

        await inter.followup.send(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] ข้ามเพลงที่กำลังเล่นอยู่")
    async def skip(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)

        guild_state = self.bot.guild_music_states.get(inter.guild.id)
        player = inter.guild.voice_client

        if not guild_state or not guild_state.current_track:
            embed = create_embed("⏭️ ไม่มีเพลงเล่นอยู่", "ไม่มีเพลงที่กำลังเล่นอยู่ให้ข้าม", color=nextcord.Color.orange())
            return await inter.response.send_message(embed=embed)

        embed = create_embed("⏭️ ข้ามเพลง", "ข้ามเพลงปัจจุบันแล้ว", color=nextcord.Color.green())
        await inter.response.send_message(embed=embed)

        await player.stop()

    @nextcord.slash_command(dm_permission=False, description="[🌺] เล่นเพลงที่กำลังกยุด")
    async def resume(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)
        
        player = inter.guild.voice_client
        if not player.paused:
            embed = create_embed("▶️ ไม่ได้หยุด", "เพลงไม่ได้หยุดอยู่", color=0xf39c12)
            return await inter.response.send_message(embed=embed)
    
        await player.resume()
        embed = create_embed("▶️ เล่นต่อ", "เพลงได้เล่นต่อแล้ว")
        await inter.response.send_message(embed=embed)

    @nextcord.slash_command(dm_permission=False, description="[🌺] หยุดเพลงที่กำลังเล่นแล้วลบคิวทั้งหมด")
    async def stop(self, inter: nextcord.Interaction):
        if not await voice_channel_check(inter):
            return
        if not inter.guild.voice_client:
            embed = create_embed("<a:9211092078964408931:1276525091588669531> ข้อผิดพลาด", "ไม่ได้เชื่อมต่อกับห้องเสียง", color=nextcord.Color.red())
            return await inter.response.send_message(embed=embed)
    
        guild_state = self.bot.guild_music_states[inter.guild.id]
        player = inter.guild.voice_client
        await player.stop()
        guild_state.queue.clear()
        guild_state.current_track = None
        embed = create_embed("⏹️ หยุดเล่น", "หยุดเล่นเพลงและล้างคิวแล้ว")
        await inter.response.send_message(embed=embed)

def setup(bot):
    bot.add_cog(MusicCog(bot))


import nextcord
from nextcord import Interaction, SlashOption
from nextcord.ext import commands
import psutil
import platform

class SystemInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @nextcord.slash_command(name="systeminfo", description="แสดงข้อมูลระบบของบอท 🖥️")
    async def systeminfo(self, interaction: Interaction):
        cpu_percent = psutil.cpu_percent()
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        system = platform.system()
        release = platform.release()

        embed = nextcord.Embed(
            title="📊 ข้อมูลระบบ",
            description="ข้อมูลการทำงานของเครื่องบอท",
            color=nextcord.Color.green()
        )

        embed.add_field(name="🖥️ ระบบปฏิบัติการ", value=f"{system} {release}", inline=False)
        embed.add_field(name="💾 การใช้ RAM", value=f"{memory.percent}%", inline=True)
        embed.add_field(name="💽 การใช้ Disk", value=f"{disk.percent}%", inline=True)
        embed.add_field(name="🧠 การใช้ CPU", value=f"{cpu_percent}%", inline=True)

        await interaction.response.send_message(embed=embed)

def setup(bot):
    bot.add_cog(SystemInfo(bot))


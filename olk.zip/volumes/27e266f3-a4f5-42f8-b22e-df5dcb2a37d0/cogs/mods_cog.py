import nextcord
from nextcord.ext import commands
from utils.music_utils import create_embed, parse_duration
from nextcord import SlashOption
import asyncio
import re
from colorama import Fore

class ModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings = {}

    @nextcord.slash_command(name="ban", description="[🛡️] แบนผู้ใช้ออกจากเซิร์ฟเวอร์")
    async def ban(self, interaction, member: nextcord.Member = SlashOption(required=True), reason: str = SlashOption(required=False, default="No reason provided")):
        await interaction.response.defer()
        if not interaction.user.guild_permissions.ban_members:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        await member.ban(reason=reason)
        embed = create_embed(f"❌ แบนผู้ใช้",f"{member.mention} ถูกแบนออกจากเซิร์ฟเวอร์เพราะ: {reason}", color=nextcord.Color.red())
        await interaction.followup.send(embed=embed)
        print(Fore.BLUE + interaction.user.name, Fore.GREEN + "ทำการแบนผู้ใช้", Fore.RED + member.name)

    @nextcord.slash_command(name="kick", description="[🛡️] เตะผู้ใช้ออกจากเซิร์ฟเวอร์")
    async def kick(self, interaction, member: nextcord.Member = SlashOption(required=True), reason: str = SlashOption(required=False, default="No reason provided")):
        await interaction.response.defer()
        if not interaction.user.guild_permissions.kick_members:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        await member.kick(reason=reason)
        embed = create_embed(f"🦶 เตะผู้ใช้",f"{member.mention} ถูกเตะออกจากเซิร์ฟเวอร์เพราะ: {reason}", color=nextcord.Color.red())
        await interaction.followup.send(embed=embed)
        print(Fore.BLUE + interaction.user.name, Fore.GREEN + "ทำการเตะผู้ใช้", Fore.RED + member.name)


    @nextcord.slash_command(name="temprole", description="[🛡️] ให้ยศผู้ใช้โดยกำหนดเวลาลบได้")
    async def temprole(self, interaction: nextcord.Interaction, member: nextcord.Member, role: nextcord.Role, duration: str = SlashOption(description="เวลาที่ต้องการ สามารถเป็น 1s 5m 1h ได้!")):
        if not interaction.user.guild_permissions.manage_roles:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        seconds = parse_duration(duration)
        if seconds is None:
            embed = create_embed("⛔ รูปแบบเวลาผิดพลาด", "กรุณาใช้รูปแบบที่ถูกต้อง เช่น 1s, 1m หรือ 1h", nextcord.Color.red())
            await interaction.response.send_message(embed=embed)
            return
        
        await member.add_roles(role)
        embed = create_embed("🛡️ เพิ่มบทบาทชั่วคราว", f"ให้บทบาท {role.name} กับ {member.mention} เป็นเวลา {duration}", nextcord.Color.green())
        await interaction.response.send_message(embed=embed)

        await asyncio.sleep(seconds)
        await member.remove_roles(role)
        embed = create_embed("⏲️ บทบาทถูกลบ", f"บทบาท {role.name} ถูกลบจาก {member.mention} หลังจาก {duration}", nextcord.Color.orange())
        await interaction.followup.send(embed=embed)

    @nextcord.slash_command(name="tempmute", description="[🛡️] ทำให้ผู้ใช้หมดเวลาตามเวลาที่คั้ง")
    async def tempmute(self, interaction: nextcord.Interaction, member: nextcord.Member, duration: str):
        if not interaction.user.guild_permissions.moderate_members:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)                             
        seconds = parse_duration(duration)
        if seconds is None:
            embed = create_embed("⛔ รูปแบบเวลาผิดพลาด", "กรุณาใช้รูปแบบที่ถูกต้อง เช่น 1s, 1m หรือ 1h", nextcord.Color.red())
            await interaction.response.send_message(embed=embed)
            return

        muted_role = nextcord.utils.get(interaction.guild.roles, name="Muted")
        if not muted_role:
            muted_role = await interaction.guild.create_role(name="Muted", permissions=nextcord.Permissions(send_messages=False, speak=False))
        
        await member.add_roles(muted_role)
        embed = create_embed("🔇 ปิดเสียงชั่วคราว", f"{member.mention} ถูกปิดเสียงเป็นเวลา {duration}", nextcord.Color.red())
        await interaction.response.send_message(embed=embed)
        
        await asyncio.sleep(seconds)
        await member.remove_roles(muted_role)
        embed = create_embed("🔊 เปิดเสียง", f"{member.mention} ถูกเปิดเสียงหลังจาก {duration}", nextcord.Color.green())
        await interaction.followup.send(embed=embed)

    @nextcord.slash_command(name="lockdown", description="[🛡️] ล้อคห้องข้อความในกรณีร้ายแรง")
    async def lockdown(self, interaction: nextcord.Interaction, channel: nextcord.TextChannel):
        if not interaction.user.guild_permissions.manage_channels:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        await channel.set_permissions(interaction.guild.default_role, send_messages=False)
        embed = create_embed("🔒 ล็อกช่อง", f"{channel.mention} ถูกล็อก ไม่มีใครสามารถส่งข้อความได้", nextcord.Color.red())
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="unlock", description="[🛡️] ปลดล้อคห้องข้อความหลังจากการล้อค")
    async def unlock(self, interaction: nextcord.Interaction, channel: nextcord.TextChannel):
        if not interaction.user.guild_permissions.manage_channels:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้")
            return await interaction.send(embed=embed)
        await channel.set_permissions(interaction.guild.default_role, send_messages=True)
        embed = create_embed("🔓 ปลดล็อกช่อง", f"{channel.mention} ถูกปลดล็อก ทุกคนสามารถส่งข้อความได้", nextcord.Color.green())
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="purge", description="[🛡️] ลบข้อความตามจำนวนที่กำหนด")
    async def purge(self, interaction: nextcord.Interaction, amount: int = SlashOption(description="จำนวนข้อความที่ต้องการลบ")):
        if not interaction.user.guild_permissions.manage_messages:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        await interaction.channel.purge(limit=amount)
        embed = create_embed("🧹 ลบข้อความ", f"ลบข้อความจำนวน {amount} ข้อความใน {interaction.channel.mention}", nextcord.Color.blue())
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @nextcord.slash_command(name="warn", description="[🛡️] เตือนผู้ใช้พร้อมเหตุผล เมื่อครบ 3 ครั้งจะเตะ")
    async def warn(self, interaction: nextcord.Interaction, member: nextcord.Member, reason: str):
        if not interaction.user.guild_permissions.kick_members:
            embed = create_embed("🚫 ไม่ได้รับอนุณาต", "คุณไม่ได้รับอนุณาตให้ไช้คำสั่งนี้!")
            return await interaction.send(embed=embed)
        if member.id not in self.warnings:
            self.warnings[member.id] = []
        self.warnings[member.id].append(reason)

        embed = create_embed("⚠️ เตือนผู้ใช้", f"{member.mention} ถูกเตือนด้วยเหตุผล: {reason}\nการเตือนทั้งหมด: {len(self.warnings[member.id])}", nextcord.Color.yellow())
        await interaction.response.send_message(embed=embed)

        if len(self.warnings[member.id]) >= 3:
            await member.kick(reason="ได้รับการเตือนเกิน 3 ครั้ง")
            kick_embed = create_embed("🦶 เตะผู้ใช้", f"{member.mention} ถูกเตะหลังจากเตือน 3 ครั้ง", nextcord.Color.red())
            await interaction.followup.send(embed=kick_embed)


def setup(bot):
    bot.add_cog(ModerationCog(bot))


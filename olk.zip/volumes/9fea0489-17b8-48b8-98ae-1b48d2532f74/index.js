const { Client } = require('discord.js-selfbot-v13');
const Discord = require('discord.js-selfbot-v13');
config = require('./config.json');

const client = new Discord.Client({
    readyStatus: true,
    checkUpdate: false
});

const largeImages = [
    'https://cdn.discordapp.com/attachments/1253665854445453324/1275405101493784657/942a49755d728ab1ccc3f22ca4b240b4.jpg?ex=66ca6250&is=66c910d0&hm=4d427362e0a38815a7a70e157a17879982fe093a4a3f0206c4f2e92801dee996&',
    'https://cdn.discordapp.com/attachments/1253665854445453324/1275433975774445632/tumblr_0dc7057c9beab9cd290c952c0429d231_8715652a_1280.gif?ex=66c9d474&is=66c882f4&hm=8947b92af4a7d4ac5670b8fd29fb0381c22d18dae08741c664844f2e1f2d9603&',
    'https://cdn.discordapp.com/attachments/1253665854445453324/1275433976256925738/162efe70b89e4c9fb4e8e55ee559f351.gif?ex=66c9d474&is=66c882f4&hm=ffbc2067c0a27a3e075dc84ddff2b346962ab072ef33272d947953a28094aa96&',
    'https://cdn.discordapp.com/banners/1179227524849475655/a_77f71f89ee811251727d3b872315984d.gif?size=1024'
    // Add more images if needed
];

let currentLargeImageIndex = 0;

client.on('ready', () => {
    var startedAt = Date.now();
    console.log(`Done ${client.user.username} Online 24/7`);

    setInterval(() => {
        const currentTime = getCurrentTime();
        const currentDate = getCurrentDate();

        const r = new Discord.RichPresence(client)
            .setApplicationId('1155496899697180762')
            .setType('LISTENING')
            .setURL('https://www.youtube.com/watch?v=wiuqbPJJGVs')
            .setState('Hi')
            .setName('x2saddddm')
            .setDetails(` 〈⏰${currentTime}〉 «» 〈👻${client.user.username}〉 `)
            .setStartTimestamp(startedAt)
            .setAssetsLargeText(`〈${currentDate}〉|〈🛸 ${Math.round(client.ws.ping)} m/s〉`)
            .setAssetsLargeImage(largeImages[currentLargeImageIndex])
            .setAssetsSmallText('x2saddddm')
            .addButton('Cheap boost', 'https://discord.gg/exclusive55')
            .addButton('discord', 'https://discord.gg/exclusive55');

        client.user.setPresence({ status: "dnd" });
        client.user.setActivity(r);

        currentLargeImageIndex = (currentLargeImageIndex + 1) % largeImages.length;
    }, 5000);
});

function getCurrentDate() {
    const a = new Date(Date.now());
    const c = { timeZone: "Asia/Bangkok", day: "2-digit", month: "2-digit", year: "numeric" };
    const formattedDate = a.toLocaleDateString("en-US", c);
    const [month, day, year] = formattedDate.split('/');
    return `${day}/${month}/${year}`;
}

function getCurrentTime() {
    const a = new Date(Date.now());
    const c = { timeZone: "Asia/Bangkok", hour: "numeric", minute: "numeric", hour12: false };
    return a.toLocaleTimeString("th-TH", c);
}

client.login(config.token);

import nextcord, asyncio
from nextcord.ext import commands

bot = commands.Bot(intents=nextcord.Intents.all())

verify_embed = nextcord.Embed(
        title="ระบบยืนยันตัวตน | ✅",
        description="""
[ ระบยศเพื่อเห็นห้องทั้งหมด ]
* ยืนยันตัวตนเพื่อเห็นห้องทั้งหมด
    * ในดิสของเรา กรุณาเคารพกฏด้วยนะ
* สามารถรับโพรเทคได้ที่
    * <#1279241997365936139>

- ด้วยรัก ผู้คุมแห่งดวงดาว""",
        color=nextcord.Color.green()
)

@bot.event
async def on_ready():
    verify_channel = bot.get_channel(1279241989421793310)
    if verify_channel:
        await asyncio.sleep(5)
        await verify_channel.purge(limit=10)
        await verify_channel.send(embed=verify_embed)
        print(f"Send embed to {verify_channel.name}")


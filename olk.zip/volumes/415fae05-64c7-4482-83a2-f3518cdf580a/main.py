#---------------------------------------------------#

import nextcord
from nextcord.ext import commands
from nextcord import Color, Embed
from nextcord import Interaction as interaction
from nextcord.ui import Button, button
from config import power
import on_ready as embed_py

#---------------------------------------------------#

bot = commands.Bot(command_prefix=">", help_command=None, intents=nextcord.Intents.all())

#---------------------------------------------------# 

@bot.event
async def on_ready():
    print(f"Login as {bot.user}, (id: {bot.user.id}")
    empty_embed.set_image("https://cdn.discordapp.com/attachments/1275047263277809785/1275140477204693142/image0.gif?ex=66c4ce9c&is=66c37d1c&hm=5d45aac42d04a390071d933273adab16490a59d187350f343c5c41fe035345b9&")
    channel = bot.get_channel(1279241989421793310)
    rule_channel = bot.get_channel(1279242033005072532)
    await rule_channel.purge(limit=10)
    await rule_channel.send(embed=rule_embed)
    view = ButtonLol(timeout=None)
    await channel.purge(limit=10)
    await channel.send(embeds=[embed_py.verify_embed, empty_embed], view=view)

#---------------------------------------------------#

empty_embed = Embed(
        title="",
        description="",
        color=Color.green()
        )

rule_embed = Embed(
        title="📜 | Rule : กฏของเซิฟเวอร์",
        description="""
กฎเซิร์ฟเวอร์ Minecraft เอาชีวิตรอด (Survival)
 * เคารพผู้อื่น: ห้ามก่อกวน ทำร้าย หรือใช้คำพูดที่ไม่เหมาะสมกับผู้เล่นคนอื่น การกระทำดังกล่าวจะส่งผลให้ถูกเตือนหรือแบน
 * ห้ามโกง: การใช้โปรแกรมโกงหรือประโยชน์จากบั๊กของเกมถือเป็นสิ่งต้องห้าม ผู้เล่นที่ถูกจับได้ว่าโกงจะถูกแบนถาวร
 * การ PVP: การต่อสู้ระหว่างผู้เล่น (PVP) นั้นอาจมีข้อจำกัดหรือโซนที่กำหนดไว้ โปรดตรวจสอบกฎเฉพาะของเซิร์ฟเวอร์
 * การดัดแปลง: การใช้ม็อดหรือโปรแกรมเสริมใด ๆ ที่ให้ความได้เปรียบที่ไม่เป็นธรรมถือเป็นสิ่งต้องห้าม
 * การสร้างสิ่งก่อสร้าง: อนุญาตให้สร้างสิ่งก่อสร้างต่าง ๆ ได้อย่างอิสระ แต่ห้ามสร้างสิ่งก่อสร้างที่ก่อความรำคาญหรือเป็นอันตรายต่อผู้เล่นอื่น
 * การขโมยและทำลาย: ห้ามขโมยทรัพย์สินหรือทำลายสิ่งก่อสร้างของผู้เล่นคนอื่นโดยไม่ได้รับอนุญาต
 * การเล่นร่วมกัน: สนับสนุนให้ผู้เล่นช่วยเหลือซึ่งกันและกัน การทำงานร่วมกันจะช่วยให้คุณอยู่รอดและสร้างสรรค์สิ่งต่าง ๆ ได้อย่างสนุกสนาน
ข้อควรจำ:
 * กฎเหล่านี้อาจมีการเปลี่ยนแปลงได้ โปรดตรวจสอบประกาศหรือกฎเพิ่มเติมในเซิร์ฟเวอร์
 * หากมีข้อสงสัยหรือปัญหาใด ๆ โปรดติดต่อทีมงานผู้ดูแลเซิร์ฟเวอร์

""",
        color=Color.green()
        )

#---------------------------------------------------# 

class ButtonLol(nextcord.ui.View):
    @button(label="ยืนยันตัวตน ✅", style=nextcord.ButtonStyle.primary)
    async def just_click(self, button: Button, interaction: nextcord.Interaction):
        role = interaction.guild.get_role(1279245067613110326)

        if role in interaction.user.roles:
            await interaction.response.send_message(f"คุณมียศอยู่แล้ว ❌", ephemeral=True)
            await sendlog_unsecces(user_name=interaction.user, user_id=interaction.user.id)
        else:
            role = interaction.guild.get_role(1279245067613110326)
            await interaction.user.add_roles(role)
            await sendlog_secces(user_name=interaction.user, user_id=interaction.user.id)

            await interaction.send("รับยศแล้ว ✅", ephemeral=True)

#---------------------------------------------------#

async def sendlog_secces(user_name, user_id):
    embed = Embed(
            title="✅ | รับยศ : สำเร็จ",
            description=f"""```| 👤 * ผู้ไช้ : {user_name}
| 💳 * ไอดีผู้ไช้ : {user_id}
```""",
            color=Color.green()
            )
    channel = bot.get_channel(1279242010083070048)
    await channel.send(embed=embed)

async def sendlog_unsecces(user_name, user_id):
    embed = Embed(
            title="❎ | รับยศ : ไม่สำเร็จ",
            description=f"""```| 👤 * ผู้ไข้ : {user_name}
| 💳 * ไอดีผู้ไช้ : {user_id}
| 📊 * สถานะ : รับยศไม่ได้
| ❓ * เหตุผล : รับยศไปแล้ว```""",
            color = Color.red()
            )
    channel = bot.get_channel(1279242010083070048)
    await channel.send(embed=embed)

#---------------------------------------------------#

bot.run(power)

#---------------------------------------------------#

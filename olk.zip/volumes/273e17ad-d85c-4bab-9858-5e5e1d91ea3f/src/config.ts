import type { NodeOptions } from "sakulink";

export const token: string = "MTI2ODUzODYyMDQ2NjE2Nzg5MQ.GvF5O8.HmV4pK0Qiof1tIhH1lGmAhq-kLYC_O5SveP0qU";
export const nodes: NodeOptions[] = [
    {
		identifier: "Roki 0",
		host: "roki1.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25572,
		secure: false,
	},
    {
		identifier: "Roki 1",
		host: "roki2.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25573,
		secure: false,
	},
    {
		identifier: "Roki 2",
		host: "roki3.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25574,
		secure: false,
	},
    {
		identifier: "Roki 3",
		host: "roki4.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25566,
		secure: false,
	},
    {
		identifier: "Roki 4",
		host: "roki5.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25567,
		secure: false,
	},
    {
		identifier: "Roki 5",
		host: "roki6.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25568,
		secure: false,
	},
    {
		identifier: "Roki 6",
		host: "roki7.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25571,
		secure: false,
	},
    {
		identifier: "Roki 7",
		host: "roki8.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25578,
		secure: false,
	},
    {
		identifier: "Roki 8",
		host: "roki9.x2saddddm.lol",
		password: "youshallnotpass",
		port: 25580,
		secure: false,
	}

];




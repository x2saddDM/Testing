import { SakulinkClient } from "./client";

new SakulinkClient().init();

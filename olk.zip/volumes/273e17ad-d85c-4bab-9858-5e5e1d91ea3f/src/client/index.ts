import express from 'express'; // Import Express
import { Client, Collection, DefaultWebSocketManagerOptions, GatewayIntentBits  } from "discord.js";
import { Manager, Player, type Payload } from "sakulink";
import { nodes, token } from "../config";
import { join } from "path";
import { readdirSync } from "fs";

DefaultWebSocketManagerOptions.identifyProperties.browser = 'Discord iOS'; // Sets it for EVERY new Client(...)

export class SakulinkClient extends Client {
    public readonly commands = new Collection<string, ICommand>();
    public readonly manager = new Manager({
        nodes: nodes, // Here we pass the nodes array with multiple nodes
        defaultSearchPlatform: "youtube music",
        send: (guild: string, payload: Payload) => this.guilds.cache.get(guild)!.shard.send(payload),
    });

    private apiServer: express.Express; // Declare the API server

    public async restart() {
        console.log("Restarting bot...");
        await this.destroy(); // Destroys the current client instance
        await this.login(token); // Re-login using the existing token
        
        // Optionally, you can call load functions again after restarting
        this.loadEvents();
        this.loadCommands();
        this.loadPlayers();
        
        console.log("Bot restarted successfully!");
    }

    private Endsong() {
        this.manager.on("queueEnd", (player) => {
            const channel = this.channels.cache.get(player.textChannel);
            channel.send({
                embeds: [
                    {
                        color: 0xffffff,
                        title: `<a:319:1268522831726252072> เพลงได้จบเเล้ว`,
                        footer: {
                            text: `💕ขอบคุณที่ใช้งาน Roki นะครับ | dev team`,
                        },
                    }
                ],
            });
        });
    }

    private Endplaylist() {
        this.manager.on("trackEnd", (player) => {
            const channel = this.channels.cache.get(player.textChannel);
            channel.send({
                embeds: [
                    {
                        color: 0xffffff,
                        title: `<a:319:1268522831726252072> เพลงใน Playlist ทั้งหมดได้จบเเล้ว`,
                        footer: {
                            text: `💕ขอบคุณที่ใช้งาน Roki นะครับ | dev team`,
                        },
                    }
                ],
            });
        });
    }

    public constructor() {
        super({
            intents: [
                GatewayIntentBits.Guilds,                         // GUILDS
                GatewayIntentBits.GuildMembers,                   // GUILD_MEMBERS
                GatewayIntentBits.GuildBans,                      // GUILD_BANS
                GatewayIntentBits.GuildEmojisAndStickers,        // GUILD_EMOJIS_AND_STICKERS
                GatewayIntentBits.GuildIntegrations,              // GUILD_INTEGRATIONS
                GatewayIntentBits.GuildWebhooks,                  // GUILD_WEBHOOKS
                GatewayIntentBits.GuildInvites,                   // GUILD_INVITES
                GatewayIntentBits.GuildVoiceStates,               // GUILD_VOICE_STATES
                GatewayIntentBits.GuildPresences,                 // GUILD_PRESENCES
                GatewayIntentBits.GuildMessages,                   // GUILD_MESSAGES
                GatewayIntentBits.GuildMessageReactions,          // GUILD_MESSAGE_REACTIONS
                GatewayIntentBits.GuildMessageTyping,             // GUILD_MESSAGE_TYPING
                GatewayIntentBits.DirectMessages,                  // DIRECT_MESSAGES
                GatewayIntentBits.DirectMessageReactions,          // DIRECT_MESSAGE_REACTIONS
                GatewayIntentBits.DirectMessageTyping,             // DIRECT_MESSAGE_TYPING
            ],
        });
        
        this.apiServer = express(); // Initialize the API server
        this.setupApi(); // Setup the API endpoints
    }

    private setupApi() {
        this.apiServer.listen(25570, '0.0.0.0', () => {
            console.log('API server is running on port 25570');
        });
    
        // Endpoint to get bot status in all servers
        this.apiServer.get('/api/roki', async (req, res) => {
            const guildCount = this.guilds.cache.size; // Number of guilds the bot is in
            const botCommandsCount = this.commands.size; // Total number of commands
            let ownerStatus = 'Error Not Found'; // Default status
            const specificGuild = this.guilds.cache.get("1214622533412716594"); // Get the specific guild
    
            if (specificGuild) {
                const ownerMember = await specificGuild.members.fetch("1179227524849475655");
                ownerStatus = ownerMember?.presence?.status || 'Error Not Found'; // Owner's status
            }
    
            const allUsers: { [key: string]: number } = {}; // Store user counts for each guild
            let totalUserCount = 0; // Total user count across all guilds
            const nodeStatus: { [key: string]: { connected: number; playing: number; uptime: string } } = {};
    
            // Fetch users in all guilds
            this.guilds.cache.forEach(guild => {
                const memberCount = guild.members.cache.size; // Count of members in the guild
                allUsers[guild.id] = memberCount; // Store count for the guild
                totalUserCount += memberCount; // Accumulate total user count
    
                // Log guild name and member count
                
            });
    
            // Node status
            this.manager.nodes.forEach(node => {
                nodeStatus[node.options.identifier] = {
                    connected: node.stats.players > 0 ? 1 : 0, // 1 if connected, else 0
                    playing: node.stats.playingPlayers > 0 ? 1 : 0, // 1 if playing, else 0
                    uptime: this.formatUptime(node.stats.uptime),
                };
            });
    
            res.json({
                guildCount,
                botCommandsCount, // Total commands fetched
                ownerStatus, // Owner's status
                allUsers: totalUserCount, // Total user count across all guilds
                nodeStatus,
            });
        });
    
        // New endpoint to get node information
        this.apiServer.get('/api/nodes', async (req, res) => {
            const nodes = this.manager.nodes.map(node => ({
                identifier: node.options.identifier,
                connected: node.stats.players > 0 ? 1 : 0,
                playingPlayers: node.stats.playingPlayers > 0 ? 1 : 0,
                uptime: this.formatUptime(node.stats.uptime),
            }));
    
            const totalConnected = nodes.reduce((acc, node) => acc + node.connected, 0);
            const totalPlaying = nodes.reduce((acc, node) => acc + node.playingPlayers, 0);
    
            res.json({
                totalConnected,
                totalPlaying,
                nodes,
            });
        });
    }
    
    
    
    
    // Function to format uptime
    private formatUptime(uptime: number): string {
        const seconds = Math.floor(uptime / 1000);
        const days = Math.floor(seconds / 86400);
        const months = Math.floor(days / 30);
        const weeks = Math.floor(days / 7);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
    
        if (months > 0) {
            return `${months} month${months > 1 ? 's' : ''}`;
        }
        if (weeks > 0) {
            return `${weeks} week${weeks > 1 ? 's' : ''}`;
        }
        if (days > 0) {
            return `${days} day${days > 1 ? 's' : ''}`;
        }
        if (hours > 0) {
            return `${hours} hour${hours > 1 ? 's' : ''}`;
        }
        if (minutes > 0) {
            return `${minutes} minute${minutes > 1 ? 's' : ''}`;
        }
        return `${seconds} second${seconds > 1 ? 's' : ''}`;
    }

    private loadEvents(): void {
        readdirSync(join(__dirname, "..", "events")).map(async (file: string) => {
            if (file.includes(".d.ts") || file.includes(".js.map")) return;
            let { event } = await import(join(__dirname, "..", "events", file));
        
            console.log(`Event loaded ${event.name}`);
            this.on(event.name, event.run.bind(null, this)); 
        
            delete require.cache[require.resolve(join(__dirname, "..", "events", file))];
        });
    }

    private loadPlayers(): void {
        readdirSync(join(__dirname, "..", "players")).map(async (file: string) => {
            if (file.includes(".d.ts") || file.includes(".js.map")) return;
            let { event } = await import(join(__dirname, "..", "players", file));
    
            console.log(`Player event loaded ${event.name}`);
    
            // Pass the SakulinkClient instance (this) to the event handler
            this.manager.on(event.name, (player: Player, payload: any) => event.run(player, payload, this));
    
            delete require.cache[require.resolve(join(__dirname, "..", "players", file))];
        });
    }     

    private loadCommands(): void {
        const commands: ICommand[] = [];
    
        const commandDirs = readdirSync(join(__dirname, "..", "commands"));
    
        commandDirs.forEach(async (directory: string) => {
            const commandFiles: string[] = readdirSync(join(__dirname, "..", "commands", directory))
                .filter((file: string) => file.endsWith(".ts") || file.endsWith(".js"));
    
            for (const file of commandFiles) {
                const commandPath = join(__dirname, "..", "commands", directory, file);
                try {
                    const { default: command } = await import(commandPath) as { default: ICommand };
    
                    if (!command || !command.name) {
                        console.warn(`Command file "${file}" is missing a "name" property.`);
                        continue;
                    }
    
                    this.commands.set(command.name, command);
                    commands.push(command);
                    console.log(`Command loaded: ${command.name}`);
    
                    delete require.cache[require.resolve(commandPath)];
                } catch (err) {
                    console.error(`Error loading command from file "${file}":`, err);
                }
            }
        });  

        this.on("ready", async () => {
            try {
                await this.application?.commands.set(commands);
                console.log("All commands registered!");
            } catch (error) {
                console.error("Error registering commands:", error);
            }
            
            this.manager.init(this.user?.id);
        });
    }  

    private antiCrash() {
        process.on("unhandledRejection", (reason) => {
            console.log("Unhandled Rejection:", reason);
        });
    
        process.on("uncaughtException", (error) => {
            console.error("Uncaught Exception:", error);
        });
    
        process.on("SIGINT", async () => {
            console.log("Bot shutting down gracefully...");
            await this.manager.destroy(); // Ensure all players are stopped before exit
            process.exit(0);
        });
    
        process.on("exit", async () => {
            console.log("Bot has exited.");
        });
    }

    public init(t?: string) {
        this.login(t ?? token);

        this.loadEvents();
        this.Endsong();
        this.Endplaylist();
        this.loadCommands();
        this.loadPlayers();
        this.antiCrash();
    }
}

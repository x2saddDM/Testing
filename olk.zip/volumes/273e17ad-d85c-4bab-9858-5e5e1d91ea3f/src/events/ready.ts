import { ActivityType } from "discord.js";

export const event: IEvent<"ready"> = {
    name: "ready",
    run: async (client) => {
        const statuses = [
            "❤️ | By x2sadddDM",
            "❤️ | Made in Ts",
            "❤️ | Quality Music",
            "❤️ | Go vibe with me!",
            `Ping ${client.ws.ping}ms`
        ];
        console.log(`Logged in as ${client.user?.tag}`);
        setInterval(() => {
            const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
            client.user?.setPresence({
                activities: [{ name: randomStatus, type: ActivityType.Playing }],//type: ignore
                status: 'online'
            });
        }, 5000);
    },
};

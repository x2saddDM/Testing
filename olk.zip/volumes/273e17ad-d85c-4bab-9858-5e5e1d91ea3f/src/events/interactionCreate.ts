import { GuildMember, CommandInteractionOptionResolver } from "discord.js";

export const event: IEvent<"interactionCreate"> = {
	name: "interactionCreate",
	run: async (client, interaction) => {
		if (interaction.isCommand()) {
			const command = client.commands.get(interaction.commandName);
			const options = <CommandInteractionOptionResolver>interaction.options;
			if (command.category === "music") {
				if (!(<GuildMember>interaction.member!).voice.channelId)
					return await interaction.reply({
						embeds: [
							{
								color: 0xffffff,
								description: "You must be in a voice channel to use this command!",
							},
						],
					});

				if (interaction.guild!.members.me!.voice.channel && interaction.guild!.members.me!.voice.channelId !== (<GuildMember>interaction.member!).voice.channelId)
					return await interaction.reply({
						embeds: [
							{
								color: 0xffffff,
								description: "You must be in the same voice channel as me to use this command!",
							},
						],
					});
			}

			command.run({
				client,
				interaction: interaction,
				args: options,
			});
		}
		if (!interaction.isAutocomplete()) return;

        const { name, value } = interaction.options.getFocused(true);
		if (interaction.commandName === 'play' && name === 'query') {
			// Fetch suggestions based on the user input
			const searchResult = await client.manager.search(value, interaction.user);
			
			const choices = searchResult.tracks.slice(0, 10).map(track => ({
				name: track.title, // Display name for the choice
				value: track.uri // Value sent back on selection
			}));
	
			await interaction.respond(choices);
		}
	},
};


import ms from "ms";
//import { adver } from "../../config";

export default {
    name: "play",
    description: "Play some music.",
    category: "music",
    options: [
        {
            name: "query",
            description: "Music URL/name",
            required: true,
            type: 3,
            autocomplete: true // Enable autocomplete for this option
        },
    ],
    run: async ({ client, interaction, args }: ICommandOptions) => {
        await interaction.deferReply();

        // Select a random ad image
    //    const randomAd = adver[Math.floor(Math.random() * adver.length)];

        // Filter online nodes
        const onlineNodes = client.manager.nodes.filter(node => node.connected);
        if (onlineNodes.size === 0) {
            await interaction.editReply({
                embeds: [
                    {
                        color: 16711680,
                        description: "🔧 **ทุกโหนดกำลังปิดปรับปรุงอยู่ กรุณาลองใหม่อีกครั้งในภายหลัง** 🔧",
                    },
                ],
            });
            return;
        }

        let player = client.manager.players.get(interaction.guildId!);

		if (!player)
			player = client.manager.create({
				node: args.getString("node") || undefined,
				guild: interaction.guild!.id,
				voiceChannel: interaction.member.voice.channelId!,
				textChannel: interaction.channel!.id,
				volume: 15,
				selfDeafen: false,
				selfMute: false,
			});

        if (player.state !== "CONNECTED") player.connect();

        const result = await client.manager.search(args.getString("query")!, interaction.user);

        switch (result.loadType) {
            case "error":
                await interaction.editReply({
                    embeds: [
                        {
                            color: 0xffffff,
                            description: "ไม่สามารถค้นหาเพลงได้ กรุณาตรวจสอบลิงก์หรือชื่อที่ถูกต้อง",
                        },
                    ],
                });
                return;
            case "empty":
                await interaction.editReply({
                    embeds: [
                        {
                            color: 16711680,
                            description: "ไม่พบผลลัพธ์ กรุณาตรวจสอบลิงก์หรือชื่อที่ถูกต้อง",
                        },
                    ],
                });
                return;
            case "playlist":
                player.queue.add(result.playlist!.tracks);
                if (!player.playing) player.play();
                await interaction.editReply({
                    embeds: [
                        {
                            color: 0xffffff,
                            title: `<a:319:1268522831726252072> ${result.playlist!.name}`,
                            url: `${args.getString("query")}`,
                            description: `┗ Duration: <-⚫-----------> ${ms(result.playlist!.duration)}`,
                            footer: {
                                text: `💕Node : ${player.node.options.identifier} | 📋 : ${args.getString("query")}`,
                            },
                            author: {
                                name: `Roki Beta | เพิ่มเพลงทั้งหมด ${result.playlist!.tracks.length} เพลงสำเร็จแล้วครับ!`,
                                icon_url: "https://cdn.discordapp.com/avatars/1268538620466167891/02652f085a6cf99a4b7055c5a2d49c6f.png?size=1024",
                            },
                        }
                       //{
                       //    color: 0xffffff,
                       //    title: `<a:DG106:1286895726147801174> Ads`,
                       //    description: randomAd.description, // Use the ad description here
                       //    image: {
                       //        url: randomAd.url, // Use the random ad image here
                       //    },
                       //},
                    ],
                });
                break;
            default:
                player.queue.add(result.tracks[0]);
                if (!player.playing) player.play();
                await interaction.editReply({
                    embeds: [
                        {
                            color: 0xffffff,
                            title: `<a:319:1268522831726252072> ${result.tracks[0].title}`,
                            url: result.tracks[0].uri,
                            thumbnail: {
                                url: result.tracks[0].artworkUrl!,
                            },
                            description: `┊ Author: ${result.tracks[0].author} \n┗ Duration: <-⚫---------->${ms(result.tracks[0].duration)}`,
                            footer: {
                                text: `💕Node : ${player.node.options.identifier} | 📋 : ${result.tracks[0].uri}`,
                            },
                            author: {
                                name: `Roki Beta | เพิ่มเพลงสำเร็จแล้วครับ!`,
                                icon_url: "https://cdn.discordapp.com/avatars/1268538620466167891/02652f085a6cf99a4b7055c5a2d49c6f.png?size=1024",
                            },
                        }
                        //{
                        //    color: 0xffffff,
                        //    title: `<a:DG106:1286895726147801174> Ads | ${randomAd.title}`,
                        //    description: randomAd.description, // Use the ad description here
                        //    image: {
                        //        url: randomAd.url, // Use the random ad image here
                        //    },
                        //},
                    ],
                });
                break;
        }
        
    },
} as ICommand;

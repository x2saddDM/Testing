export default {
    name: "queue",
    description: "Shows the current song queue.",
    category: "music",
    run: async ({ client, interaction }: ICommandOptions) => {
        const player = client.manager.players.get(interaction.guildId!);
        if (!player || !player.queue || !player.queue.length) {
            return await interaction.reply({
                embeds: [
                    {
                        color: 0xffffff,
                        description: "ไม่มีเพลงในคิวในเซิร์ฟเวอร์นี้!",
                    },
                ],
            });
        }

        const queue = player.queue;
        const current = player.queue.current;

        let queueDescription = `**Now playing:**\n${current.title}\n\n`;

        // Loop through the next songs in the queue and list them
        if (queue.length > 1) {
            queueDescription += "**Up next:**\n";
            queue.slice(1, 10).forEach((track, index) => {
                queueDescription += `${index + 1}. ${track.title}\n`;
            });
        } else {
            queueDescription += "No more songs in the queue!";
        }

        return await interaction.reply({
            embeds: [
                {
                    color: 0xffffff,
                    description: queueDescription,
                },
            ],
        });
    },
} as ICommand;

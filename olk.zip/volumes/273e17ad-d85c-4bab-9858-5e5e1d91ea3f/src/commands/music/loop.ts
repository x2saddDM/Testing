export default {
	name: "loop",
	description: "Loop the current song or queue.",
	category: "music",
	options: [
		{
			name: "type",
			description: "Type of loop",
			type: 3,
			required: true,
			choices: [
				{
					name: "None",
					value: "none",
				},
				{
					name: "Song",
					value: "song",
				},
				{
					name: "Queue",
					value: "queue",
				},
			],
		},
	],
	run: async ({ client, interaction, args }: ICommandOptions) => {
		const player = client.manager.players.get(interaction.guildId!);
		if (!player || !player.queue.current)
			return await interaction.reply({
				embeds: [
					{
						color: 0xffffff,
						description: "ไม่มีเพลงเล่นในเซิร์ฟเวอร์นี้!",
					},
				],
			});

		const loopType = args.getString("type");

		switch (loopType) {
			case "queue": {
				player.setQueueRepeat(true);
				await interaction.reply({
					embeds: [
						{
							color: 0xffffff,
							description: "ตอนนี้กำลัง loop คิวทั้งหมดแล้ว!",
						},
					],
				});
			}
			case "song": {
				player.setTrackRepeat(true);
				await interaction.reply({
					embeds: [
						{
							color: 0xffffff,
							description: "ตอนนี้กำลัง loop เพลงปัจจุบันแล้ว!",
						},
					],
				});
			}
			default: {
				player.setTrackRepeat(false);
				player.setQueueRepeat(false);
				await interaction.reply({
					embeds: [
						{
							color: 0xffffff,
							description: "ปิด loop เเล้ว!",
						},
					],
				});
			}
		}
	},
} as ICommand;

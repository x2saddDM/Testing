import { stripIndent } from "common-tags";
import ms from "ms";

export default {
  name: "node",
  description: "Get the nodes information of the bot.",
  category: "information",
  options: [
    {
      name: "ephemeral",
      type: 5, // BOOLEAN type
      description: "Whether the information should be visible only to you.",
      required: false,
    },
  ],
  run: async ({ client, interaction }: ICommandOptions) => {
    const ephemeral = interaction.options.getBoolean("ephemeral") ?? false;
    await interaction.deferReply({ ephemeral });

    // Get nodes data
    const nodes = client.manager.nodes.map((node) => ({
      options: node.options,
      stats: node.stats,
      connected: node.connected,
    }));

    // Calculate total connected and playing rooms
    const totalConnected = nodes.reduce((acc, node) => acc + node.stats.players, 0);
    const totalPlaying = nodes.reduce((acc, node) => acc + node.stats.playingPlayers, 0);

    const getEmoji = (isOnline: boolean) => (isOnline ? "<a:319:1268522831726252072>" : "<a:318:1268522835526025390>");

    // Create embed with summary and fields for each node
    const embed = {
      author: {
        name: ` ${client.user!.username} nodes information ✨`,
        icon_url: client.user!.displayAvatarURL(),
      },
      color: 0x5865f2, // Discord's brand color for embed
      fields: [
        {
          name: "<a:emoji_41:1288184833247416430> **All nodes**",
          value: stripIndent`
            \`\`\`ml
            Connected : ${totalConnected} Room
            Playing : ${totalPlaying} Room
            \`\`\`
          `,
          inline: false, // Set to false to have it on a new line
        },
        ...nodes.map((node) => ({
          inline: true,
          name: `${getEmoji(node.connected)} **${node.options.identifier}**`, // Removed index indicator
          value: stripIndent`
            \`\`\`yaml
            Connected: ${node.stats.players} Room
            Playing: ${node.stats.playingPlayers} Room
            CPUUsge: ${(node.stats.cpu.lavalinkLoad * 100).toFixed(1)} %
            RamUsge: ${(node.stats.memory.used / 1048576).toFixed(1)} MB
            RamMax: ${(node.stats.memory.reservable / 1048576).toFixed(1)} GB
            Uptime: ${ms(node.stats.uptime)}
            \`\`\`
          `,
        })),
      ],
      timestamp: new Date(),
    };



    interaction.editReply({
      embeds: [embed],
      ephemeral,
    });
  },
} as ICommand;



export default {
    name: "reload",
    description: "Reload commands, events or restart the bot",
    category: "information",
    options: [
        {
            name: "command",
            description: "Reload commands",
            type: 1, // 1 represents a subcommand
        },
        {
            name: "event",
            description: "Reload events",
            type: 1, // 1 represents a subcommand
        },
        {
            name: "restart",
            description: "Restart the bot",
            type: 1, // 1 represents a subcommand
        },
    ],
    run: async ({ client, interaction }: ICommandOptions) => {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "command") {
            await client.reload("command");
            return interaction.reply({ content: "Commands reloaded successfully!", ephemeral: true });
        } else if (subcommand === "event") {
            await client.reload("event");
            return interaction.reply({ content: "Events reloaded successfully!", ephemeral: true });
        } else if (subcommand === "restart") {
            await interaction.reply({ content: "Restarting the bot...", ephemeral: true });
            await client.restart(); // Call the restart function on your client
        } else {
            return interaction.reply({ content: "Invalid reload option", ephemeral: true });
        }
    },
} as ICommand;

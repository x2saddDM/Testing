export default {
    name: "ping",
    description: "Get the ping of the bot.",
    category: "information",
    run: async ({ client, interaction }: ICommandOptions) => {
        const ping = client.ws.ping;
        const maxPing = 1000; // Max ping value to represent
        const barLength = 10; // Length of the progress bar
        const greenBars = Math.floor((ping / maxPing) * barLength);
        const yellowBars = barLength - greenBars;

        // Create the progress bar string
        const progressBar = `${"🟩".repeat(greenBars)}${"🟨".repeat(yellowBars)}`;

        await interaction.reply({
            embeds: [
                {
                    color: 0xffffff,
                    description: `> ** \`${ping}ms\` **\n${progressBar}`,
                },
            ],
            ephemeral: true, // Make the reply ephemeral
        });
    },
} as ICommand;

export const event: IPlayerEvent<"nodeConnect"> = {
	name: "nodeConnect",
	run: async (node) => {
		console.log(`Node connected: ${node.options.identifier}`);
	},
};

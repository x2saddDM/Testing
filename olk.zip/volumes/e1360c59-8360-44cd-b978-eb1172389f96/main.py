from flask import Flask, request, jsonify
import json
from datetime import datetime

app = Flask(__name__)

# Load the initial data from data.json
def load_data():
    try:
        with open('data.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Save data to data.json
def save_data(data):
    with open('data.json', 'w') as file:
        json.dump(data, file)

# Simulating a database to store verification status
verified_users = load_data()

# API to verify user
@app.route('/api/verify/<user_id>', methods=['POST'])
def verify_user(user_id):
    if user_id not in verified_users:
        # Mark user as verified and save the verification date
        verified_users[user_id] = {
            "global_name": user_id,  # Assuming user_id as global name for simplicity
            "verified_date": datetime.now().isoformat()
        }
        save_data(verified_users)
        return jsonify({'status': 'verified'}), 200
    return jsonify({'error': 'Already verified'}), 400

# API to check if a user is verified
@app.route('/api/check/<user_id>', methods=['GET'])
def check_verification(user_id):
    if user_id in verified_users:
        return jsonify({'status': 'verified'}), 200
    return jsonify({'status': 'not verified'}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1028, debug=True)

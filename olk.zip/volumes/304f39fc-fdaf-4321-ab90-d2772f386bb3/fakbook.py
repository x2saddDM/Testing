import nextcord
from nextcord.ext import commands
from nextcord import ui
from config_manager import get_token

class MessageInputModal(ui.Modal):
    def __init__(self, user: nextcord.Member):
        super().__init__(title="BeastClub | ฝากบอก")
        self.user = user
        self.message = nextcord.ui.TextInput(label="ใส่ข้อความที่ต้องการ", style=nextcord.TextInputStyle.paragraph)
        self.add_item(self.message)

    async def callback(self, interaction: nextcord.Interaction):
        await interaction.response.defer()

        if self.user is None:
            await interaction.response.send_message("❌ ไม่พบผู้ใช้!", ephemeral=True)
            return


        try:
            await self.user.send(self.message.value)
            await interaction.followup.send("✅ ส่งข้อความเรียบร้อย", ephemeral=True)
        except nextcord.Forbidden:
            await interaction.followup.send("❌ ผู้ใช้นี้ไม่เปิดข้อความส่วนตัว", ephemeral=True)

class UserSelect(ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder="เลือกผู้ใช้ที่ต้องการส่งข้อความแบบลับๆ 🤫", min_values=1, max_values=1)

    async def callback(self, interaction: nextcord.Interaction):
        selected_user = self.values[0]
        
        user = interaction.guild.get_member(selected_user.id)

        if user is None:
            await interaction.response.send_message("❌ ไม่พบผู้ใช้ที่เลือก", ephemeral=True)
            return

        modal = MessageInputModal(user)
        await interaction.response.send_modal(modal)


class BeastClub(commands.Bot):
    def __init__(self):
        super().__init__(intents=nextcord.Intents.all())

    async def on_ready(self):
        print(f"Logged in as {self.user}")

bot = BeastClub()

@bot.slash_command(
        name="pls_shut_up",
        description="Select a user and send them a message",
    )
async def select_user(interaction: nextcord.Interaction):
    await interaction.response.defer()
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.send(
                f"# คือมึงรู้ว่าไม่ไช่แอดมิน ยังจะใช้คำสั่งนี้อีกหรอ @here {interaction.user.mention} แม่งจะใช้คำสั่งแอดมินอะ รุมประจารมานนนนน!!!"
        )
    view = ui.View(timeout=None)
    user_select = UserSelect()
    view.add_item(user_select)
    channel = bot.get_channel(1292181287225790505)
    embed=nextcord.Embed(
            title="BeastClub | ฝากบอก ✉️",
            description="ส่งข้อความหาคนอื่นๆแบบลับๆ\nโดยที่แม้แต่แม่แอดมินก็ไม่รู้ว่าใครส่งข้อวามนั้นๆ",
            color=nextcord.Color.blurple()
            )
    embed.set_image('https://media.discordapp.net/attachments/729671788187091024/1292180416329158656/image0.gif?ex=6702cc4a&is=67017aca&hm=76cd8b87910b57b3833db37b22e07765bad206b3bf65f42af4d97176addd1189&')
    await channel.purge(limit=10)
    await channel.send(embed=embed, view=view)
    await interaction.followup.send("เริ่มต้นเรียบร้อยครับ | KaityXD bot v0.1", ephemeral=True)

bot.run(get_token())


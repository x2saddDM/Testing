import json
import os, nextcord

CONFIG_FILE = "config.json"

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {
        "token": "MTI3ODY4Mzk0MjU1NTQ4NDIyMg.Gy22q2.G7ukc3FUUkOVyS8A1sSvO5T3Iaz0kJrb6Udg_0",
        "log_channel_id": 1281964308019941477,
        "shop_channel_id": 1279387925372600340,
        "roles": {
            "Left Arm": {"id": 1278709445089562737, "price": 600, "emoji": "💪"},
            "Right Arm": {"id": 1278709581769605200, "price": 600, "emoji": "💪"},
            "Left Leg": {"id": 1278709714271866892, "price": 400, "emoji": "🦵"},
            "Right Leg": {"id": 1280391008923684884, "price": 400, "emoji": "🦵"},
            "Full Body": {"id": 1280391038900502618, "price": 1000, "emoji": "☢️"}

        },
        "shop_embed": {
            "title": "[ ร้านค้าเหรียญ ]",
            "description": "**Shop > ร้านค้ายศที่ซื้อด้วยเหรียญ\nโดยเหรียญสามารถหาได้จากการออนห้องทุกๆ 1 ชม.**",
            "color": nextcord.Color.purple(),
            "image_url": "https://media.discordapp.net/attachments/1279368757797458013/1282055716474982521/image0.gif?ex=66ddf6ee&is=66dca56e&hm=d8563c986d1092b34e8d1909991840090b1c1b0a3d1d35f03ce22823ed2e5d37&"
        }
    }

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

def get_config():
    return load_config()

def update_config(key, value):
    config = load_config()
    keys = key.split('.')
    current = config
    for k in keys[:-1]:
        if k not in current:
            current[k] = {}
        current = current[k]
    current[keys[-1]] = value
    save_config(config)

def get_token():
    return get_config()["token"]

def get_log_channel_id():
    return get_config()["log_channel_id"]

def get_shop_channel_id():
    return get_config()["shop_channel_id"]

def get_roles():
    return get_config()["roles"]

def get_shop_embed():
    return get_config()["shop_embed"]

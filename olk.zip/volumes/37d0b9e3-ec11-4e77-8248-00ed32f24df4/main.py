import nextcord
from nextcord.ext import commands
import datetime
import config
import pytz
import aiohttp
import os

intents = nextcord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents)

LOG_CHANNEL_ID = 1277222568582975528
timezone = pytz.timezone('Asia/Bangkok')
ATTACHMENT_DIR = "downloaded_attachments"

if not os.path.exists(ATTACHMENT_DIR):
    os.makedirs(ATTACHMENT_DIR)

async def download_attachment(attachment):
    file_path = os.path.join(ATTACHMENT_DIR, attachment.filename)
    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as resp:
            if resp.status == 200:
                with open(file_path, 'wb') as f:
                    f.write(await resp.read())
    return file_path

async def send_log(channel, title, description, emoji, color=nextcord.Color.blue(), file=None):
    embed = nextcord.Embed(title=f"{emoji} {title}", description=description, color=color, timestamp=datetime.datetime.now(timezone))
    if file:
        file = nextcord.File(file)
        embed.set_image(url=f"attachment://{os.path.basename(file.filename)}")
        await channel.send(embed=embed, file=file)
    else:
        await channel.send(embed=embed)

@bot.event
async def on_ready():
    print(f'{bot.user} ได้เชื่อมต่อกับ Discord แล้ว!')

@bot.event
async def on_voice_state_update(member, before, after):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if before.channel != after.channel:
        if after.channel:
            await send_log(log_channel, "เข้าร่วมช่องเสียง", f"{member.name} เข้าร่วม {after.channel.name}", "🎙️")
        else:
            await send_log(log_channel, "ออกจากช่องเสียง", f"{member.name} ออกจาก {before.channel.name}", "🔇")

@bot.event
async def on_message(message):
    if message.attachments:
        for attachment in message.attachments:
            await download_attachment(attachment)

@bot.event
async def on_message_delete(message):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    description = f"ข้อความโดย {message.author.name} ถูกลบใน {message.channel.name}\nเนื้อหา: {message.content}"
    
    if message.attachments:
        for attachment in message.attachments:
            file_path = os.path.join(ATTACHMENT_DIR, attachment.filename)
            if os.path.exists(file_path):
                await send_log(log_channel, "ข้อความและไฟล์แนบถูกลบ", description, "🗑️", file=file_path)
                return
    
    await send_log(log_channel, "ข้อความถูกลบ", description, "🗑️")

@bot.event
async def on_message_edit(before, after):
    if before.content != after.content:
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        await send_log(log_channel, "ข้อความถูกแก้ไข", f"ข้อความโดย {before.author.name} ถูกแก้ไขใน {before.channel.name}\nก่อน: {before.content}\nหลัง: {after.content}", "✏️")

@bot.event
async def on_member_update(before, after):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if before.roles != after.roles:
        new_roles = set(after.roles) - set(before.roles)
        removed_roles = set(before.roles) - set(after.roles)
        if new_roles:
            await send_log(log_channel, "เพิ่มบทบาท", f"{after.name} ได้รับบทบาท: {', '.join(role.name for role in new_roles)}", "⬆️")
        if removed_roles:
            await send_log(log_channel, "ลบบทบาท", f"{after.name} ถูกลบบทบาท: {', '.join(role.name for role in removed_roles)}", "⬇️")

@bot.event
async def on_member_ban(guild, user):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    await send_log(log_channel, "สมาชิกถูกแบน", f"{user.name} ถูกแบนจากเซิร์ฟเวอร์", "🚫", nextcord.Color.red())

@bot.event
async def on_member_unban(guild, user):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    await send_log(log_channel, "ยกเลิกการแบนสมาชิก", f"{user.name} ถูกยกเลิกการแบนจากเซิร์ฟเวอร์", "🎊", nextcord.Color.green())

bot.run(config.token)

import discord, json, asyncio
from datetime import datetime, timedelta
from discord import *
from discord.ui import View, Select
from discord.gateway import DiscordWebSocket, _log


async def identify(self):
    payload = {
        'op': self.IDENTIFY,
        'd': {
            'token': self.token,
            'properties': {
                '$os': sys.platform,
                '$browser': 'Discord Android',
                '$device': 'Discord Android',
                '$referrer': '',
                '$referring_domain': ''
            },
            'compress': True,
            'large_threshold': 250,
            'v': 3
        }
    }

    if self.shard_id is not None and self.shard_count is not None:
        payload['d']['shard'] = [self.shard_id, self.shard_count]

    state = self._connection
    if state._activity is not None or state._status is not None:
        payload['d']['presence'] = {
            'status': state._status,
            'game': state._activity,
            'since': 0,
            'afk': False
        }

    if state._intents is not None:
        payload['d']['intents'] = state._intents.value

    await self.call_hooks('before_identify', self.shard_id, initial=self._initial_identify)
    await self.send_as_json(payload)
    _log.info('Shard ID %s has sent the IDENTIFY payload.', self.shard_id)


DiscordWebSocket.identify = identify
config = json.load(open("config.json", encoding="utf-8"))

# Set up the intents to listen for presence updates
intents = discord.Intents.all()

client = discord.Bot(intents=intents)

class Utils():
    @staticmethod
    async def isWhitelisted(ctx) -> bool:
        if (
            str(ctx.author.id) in open("assets/whitelist.txt", "r").read().splitlines()
            or str(ctx.author.id) == config["owner"]
        ):
            return True
        else:
            return False

@client.event
async def on_ready():
    print(f'Logged in as {client.user}!')

    # Change bot status to Do Not Disturb and set activity
    await client.change_presence(activity=discord.Game(name="Assisting to x2sadddDM"))
    print("Bot status updated to DND with activity!")


@client.slash_command(
    guild_ids=[config["guild_id"]],
    name="whitelist",
    description="Whitelist a user with ease."
)
async def whitelist(
    ctx: ApplicationContext, user: discord.Option(discord.Member, "Member to whitelist", required=True)  # type: ignore
):
    owner = await client.fetch_user(int(config['owner']))
    
    # Check if the user is the bot owner
    if str(ctx.author.id) != config["owner"]:
        embed = discord.Embed(
            title="Hang on...",
            description=f"You are not whitelisted to use this command. If you're the bot owner and require whitelisting, please contact {owner.mention} to be added as the owner.",
            color=discord.Color.purple()
        )
        embed.set_footer(text="© x2sadddDM.lol, All Rights Reserved.", icon_url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
        embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
        
        return await ctx.respond(embed=embed)

    # If the user is not whitelisted and is not the owner
    if (
        not (str(user.id) in open("assets/whitelist.txt", "r").read().splitlines())
        and str(user.id) != config["owner"]
    ):
        with open("assets/whitelist.txt", "a") as whitelist:
            whitelist.write(str(user.id) + "\n")

        embed = discord.Embed(
            title="Success",
            description=f"Successfully whitelisted {user}.",
            color=0xED00FF
        )
        return await ctx.respond(embed=embed)

    # If the user is already the owner
    elif str(user.id) == config["owner"]:
        embed = discord.Embed(
            title="Already Owner!",
            description="You can't run this command; you are already the owner of this bot!",
            color=0xFF0004
        )
        return await ctx.respond(embed=embed)

    # If the user is already whitelisted
    else:
        embed = discord.Embed(
            title="Already Whitelisted!",
            description=f"{user} is already whitelisted!",
            color=0xFF0004
        )
        return await ctx.respond(embed=embed)






@client.slash_command(
    guild_ids=[config["guild_id"]],
    name="unwhitelist",
    description="Unwhitelist a user with ease.",
)
async def unwhitelist(
    ctx: ApplicationContext, user: discord.Option(discord.Member, "Member to unwhitelist", required=True)# type: ignore
):
    owner = await client.fetch_user(int(config['owner']))
    
    # Check if the user is the bot owner
    if str(ctx.author.id) != config["owner"]:
        embed = discord.Embed(
            title="Hang on...",
            description=f"You are not whitelisted to use this command. If you're the bot owner and require whitelisting, please contact {owner.mention} to be added as the owner.",
            color=discord.Color.purple()
        )
        embed.set_footer(text="© x2sadddDM.lol, All Rights Reserved.", icon_url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
        embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
        
        return await ctx.respond(embed=embed)

    if (
        not (str(user.id) in open("assets/whitelist.txt", "r").read().splitlines())
        and str(user.id) != config["owner"]
    ):
        embed = discord.Embed(
            title="User Not Whitelisted!",
            description=f"{user} is currently not whitelisted.",
            color=0xFF0004
        )

        return await ctx.respond(embed=embed)

    elif str(user.id) == config["owner"]:
        return await ctx.respond(
            embed=discord.Embed(
                title=f"Already Owner!",
                description=f"You are currently the owner! You cannot unwhitelist yourself.",
                color=0xFF0004
            )
        )

    else:
        with open("assets/whitelist.txt", "r+") as whitelist:
            whitelisted = whitelist.readlines()
            whitelist.seek(0)
            for line in whitelisted:
                if not (str(user.id) in line):
                    whitelist.write(line)
            whitelist.truncate()

        embed = discord.Embed(
            title="Success",
            description=f"Successfully Removed {user}",
            color=0xED00FF
        )

        return await ctx.respond(embed=embed)


@client.slash_command(
    guild_ids=[config["guild_id"]],
    name="help",
    description="Requests a help panel.",
)
async def help(ctx: discord.ApplicationContext):  # type: ignore
    # Initial Embed with Help Information
    embed = discord.Embed(
        title="x2sadddDM Assistant | Help Panel [/]",
        description="Select an option from the dropdown menu below for more help.",
        color=discord.Color.purple()
    )
    embed.set_footer(text="© x2sadddDM.lol, All Rights Reserved.", icon_url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/1287470105965494292/2f76ed4a610c854dd1b3393e1db490c2.png?size=1024")
    embed.set_image(url="https://cdn.discordapp.com/banners/1287470105965494292/a_77f71f89ee811251727d3b872315984d.gif?size=1024")

    # Create a Select menu with options
    sel = Select(
        placeholder="Choose a help category...",
        options=[
            discord.SelectOption(label="General Help", description="Basic commands and usage"),
            discord.SelectOption(label="Music Commands", description="Learn how to play music")
        ]
    )

    # Define what happens when an option is selected
    async def callback(interaction: discord.Interaction):
        if sel.values[0] == "General Help":
            embed.title = "General Help"
            embed.description = (
                "Here are some basic commands and usage guidelines:\n"
                "1. `/ping` - Check bot's latency\n"
                "2. `/help` - Display help information\n"
                "3. `/invite` - Get the bot's invite link"
            )
            embed.color = discord.Color.green()

        elif sel.values[0] == "Music Commands":
            embed.title = "Music Commands"
            embed.description = (
                "> Roki \n\n"
                "- </play:1268540146207293546> - Play the song you want!\n"
                "- </pause:1268540146207293545> - letme change the des!\n"
                "- </queue:1287452809129758833> - letme change the des!\n"
                "- </stop:1268540146207293549> - letme change the des!\n"
                "- </node:1268540146207293542> - letme change the des!\n"
                "- </volume:1268540146504957952> - letme change the des!\n"
                "- </autoplay:1268540146207293541> - letme change the des!\n"
                "- </loop:1268540146207293543> - letme change the des!\n"
                "- </ping:1268540146207293544> - letme change the des!\n"
                "- </resume:1268540146207293547> - letme change the des!\n"
                "- </skip:1268540146207293548> - letme change the des!\n"
                "> Mayumi\n"
                "adding\n"
                "- `/skip` - Skip the current song"
            )
            embed.color = discord.Color.blue()

        await interaction.response.edit_message(embed=embed, view=view)

    sel.callback = callback  # Attach the callback to the Select menu

    # Add the Select menu to a view and send the message with the embed
    view = View()
    view.add_item(sel)

    # Send the initial embed with the view
    message = await ctx.respond(embed=embed, view=view)

    # Timeout logic: wait for 60 seconds (adjust as needed)
    await asyncio.sleep(60)

    # After timeout, update the embed to indicate the timeout
    embed.title = "Help Panel Timed Out"
    embed.description = "This help session has timed out. Please use the `/help` command again if needed."
    embed.color = discord.Color.red()
    embed.set_image(url=None)

    # Disable the Select menu after timeout
    view.clear_items()  # This removes the select menu

    # Edit the original message with the timeout embed and no interaction
    await message.edit_original_response(embed=embed, view=view, delete_after=5)






    




# Replace 'YOUR_BOT_TOKEN' with your actual bot token
client.run(config["token"])

import nextcord
from nextcord.ext import commands, tasks
from nextcord import ButtonStyle, Interaction, SelectOption
from nextcord.ui import Button, View, Select
import json
import os
import time
import logging
from datetime import datetime
import asyncio
import config_manager

intents = nextcord.Intents.default()
intents.message_content = True
intents.voice_states = True
bot = commands.Bot(command_prefix=">", intents=intents)

LOG_CHANNEL_ID = config_manager.get_log_channel_id()
DATA_FILE = "user_data.json"

ROLES = config_manager.get_roles()

logging.basicConfig(filename='bot_log.txt', level=logging.INFO,
                    format='%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding='utf-8') as f:
            return json.load(f)
    return {"users": {}}

def save_data():
    with open(DATA_FILE, "w", encoding='utf-8') as f:
        json.dump(user_data, f, ensure_ascii=False, indent=4)

user_data = load_data()

def get_user_data(user_id):
    user_id = str(user_id)
    if user_id not in user_data["users"]:
        user_data["users"][user_id] = {"points": 0, "voice_time": 0, "last_award_time": 0}
    return user_data["users"][user_id]

async def update_voice_time(user_id, duration):
    user = get_user_data(user_id)
    user["voice_time"] += duration
    points_earned = await check_and_award_points(user_id)
    save_data()
    return points_earned

async def check_and_award_points(user_id):
    user = get_user_data(user_id)
    hours_accumulated = int(user["voice_time"] // 3600)
    points_to_award = hours_accumulated - (user["points"] - user["points"] % 1)

    if points_to_award > 0:
        user["points"] += points_to_award

        await send_log_embed(
            "ได้รับเหรียญ 🪙",
            f"ผู้ใช้ <@{user_id}> ได้รับ {points_to_award} เหรียญ 🪙 ทั้งหมด: {user['points']} เวลาในช่องเสียงทั้งหมด: {user['voice_time']/3600:.2f} ชั่วโมง",
            nextcord.Color.green()
        )

    return points_to_award

async def send_log_embed(title, description, color):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        embed = nextcord.Embed(title=title, description=description, color=color)
        await log_channel.send(embed=embed)

class ShopView(nextcord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(self.check_button())
        self.add_item(self.role_select())

    def check_button(self):
        button = Button(label="เช็คเหรียญ 🪙", style=ButtonStyle.primary)
        button.callback = self.check_button_callback
        return button

    async def check_button_callback(self, interaction: Interaction):
        user = get_user_data(interaction.user.id)
        await interaction.response.send_message(
            f"คุณมี {user['points']} เหรียญ และใช้เวลาในช่องเสียง {user['voice_time']/3600:.2f} ชั่วโมง",
            ephemeral=True
        )

    def role_select(self):
        select = Select(
            placeholder="[ เลือกซื้อยศได้เลยนะ ]",
            options=[
                SelectOption(label=f"{name.capitalize()} {info['emoji']}", description=f"ราคา: {info['price']} 🪙", value=name)
                for name, info in ROLES.items()
            ]
        )
        select.callback = self.select_menu_callback
        return select

    async def select_menu_callback(self, interaction: Interaction):
        user = get_user_data(interaction.user.id)
        selected_role = ROLES[interaction.data['values'][0]]

        if user['points'] >= selected_role['price']:
            role = interaction.guild.get_role(selected_role['id'])
            if role:
                await interaction.user.add_roles(role)
                user['points'] -= selected_role['price']
                save_data()
                await interaction.response.send_message(f"คุณได้ซื้อยศ {role.name} ด้วย {selected_role['price']} เหรียญ🪙", ephemeral=True)
                await send_log_embed(
                    "ซื้อยศ",
                    f"ผู้ใช้ <@{interaction.user.id}> ซื้อยศ {role.name} ด้วย {selected_role['price']} เหรียญคงเหลือ: {user['points']}",
                    nextcord.Color.blue()
                )
            else:
                await interaction.response.send_message(f"ไม่พบยศที่เลือก", ephemeral=True)
        else:
            await interaction.response.send_message(f"คุณมีเหรียญไม่เพียงพอที่จะซื้อยศนี้ คุณมี {user['points']} เหรียญ 🪙", ephemeral=True)

@bot.event
async def on_ready():
    print(f"บอทพร้อมใช้งานแล้ว เข้าสู่ระบบในชื่อ {bot.user}")
    check_voice_time.start()

    shop_embed_config = config_manager.get_shop_embed()
    embed = nextcord.Embed(
        title=shop_embed_config["title"],
        description=shop_embed_config["description"],
        color=shop_embed_config["color"]
    )
    embed.set_image(url=shop_embed_config["image_url"])

    channel = bot.get_channel(config_manager.get_shop_channel_id())
    view = ShopView()
    await channel.purge(limit=100)
    await channel.send(embed=embed, view=view)


@bot.event
async def on_voice_state_update(member, before, after):
    user_id = str(member.id)
    now = time.time()

    if before.channel is None and after.channel is not None:
        get_user_data(user_id)["voice_join_time"] = now
    elif before.channel is not None and after.channel is None:
        join_time = get_user_data(user_id).get("voice_join_time", now)
        duration = now - join_time
        points_earned = await update_voice_time(user_id, duration)
        if points_earned > 0:
            await member.send(f"ยินดีด้วย! คุณได้รับ {points_earned} เหรียญ 🪙 จากการอยู่ในช่องเสียง")

@tasks.loop(minutes=5)
async def check_voice_time():
    now = time.time()
    for user_id, data in user_data["users"].items():
        if "voice_join_time" in data:
            duration = now - data["voice_join_time"]
            points_earned = await update_voice_time(user_id, duration)
            data["voice_join_time"] = now
            if points_earned > 0:
                member = bot.get_user(int(user_id))
                if member:
                    await member.send(f"ยินดีด้วย! คุณได้รับ {points_earned} เหรียญ 🪙 จากการอยู่ในช่องเสียง")

@bot.command(name="takepoints")
@commands.has_permissions(administrator=True)
async def givepoints(ctx, member: nextcord.Member, amount: int):
    user = get_user_data(member.id)
    user["points"] -= amount
    if user["points"] < 0 :
        user["points"] = 0
    save_data()

    await send_log_embed(
        "ลบเหรียญ 🪙",
        f"แอดมิน <@{ctx.author.id}> ลบ {amount} เหรียญของ <@{member.id}> เหลือ: {user['points']}",
        nextcord.Color.gold()
    )

    await ctx.send(f"ลบเหรียญจำนวน {amount} จาก {member.mention} เหลือ: {user['points']}")

@bot.command(name="givepoints")
@commands.has_permissions(administrator=True)
async def givepoints(ctx, member: nextcord.Member, amount: int):
    if ctx.author.id == 242329614494466048 or ctx.author.id == 1118160684119752834:
        user = get_user_data(member.id)
        user["points"] += amount
        if user["points"] < 0 :
            user["points"] = 0
        save_data()

        await send_log_embed(
            "ให้เหรียญ 🪙",
            f"แอดมิน <@{ctx.author.id}> ให้ {amount} เหรียญ 🪙 แก่ <@{member.id}> ทั้งหมด: {user['points']}",
            nextcord.Color.gold()
    )

        await ctx.send(f"ให้ {amount} เหรียญ 🪙 แก่ {member.mention} ทั้งหมด: {user['points']}")
    else:
        ctx.send("คุณไม่ได้รับอนุญาต ให้ใช้คำสั่งนี้")
@bot.command(name="pay")
async def pay(ctx, recipient: nextcord.Member, amount: int):
    sender = get_user_data(ctx.author.id)
    recipient_data = get_user_data(recipient.id)

    if sender["points"] < amount:
        await ctx.send("คุณมีเหรียญ 🪙ไม่เพียงพอที่จะโอน")
        return

    sender["points"] -= amount
    recipient_data["points"] += amount
    save_data()

    await send_log_embed(
        "การโอนเหรียญ 🪙",
        f"ผู้ใช้ <@{ctx.author.id}> โอน {amount} ให้ <@{recipient.id}> คงเหลือของผู้โอน: {sender['points']} 🪙 ทั้งหมดของผู้รับ: {recipient_data['points']}",
        nextcord.Color.orange()
    )

    await ctx.send(f"คุณได้โอน {amount} ให้ {recipient.mention} สำเร็จแล้ว")

@bot.command(name="checkpoints")
async def checkpoints(ctx, member: nextcord.Member = None):
    member = member or ctx.author
    user = get_user_data(member.id)
    await ctx.send(f"{member.mention} มี {user['points']} เหรียญ 🪙 และใช้เวลาในช่องเสียง {user['voice_time']/3600:.2f} ชั่วโมง")


bot.run(config_manager.get_token())
